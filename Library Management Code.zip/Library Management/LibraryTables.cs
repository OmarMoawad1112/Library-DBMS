﻿using System.Data;
using System.Data.SqlClient;

namespace Library_Management
{
    public partial class LibraryTables : Form
    {
        SqlConnection con = new SqlConnection("Data Source=Matrix;Initial Catalog=LibraryManagementSystem;Integrated Security=True");

        public LibraryTables()
        {
            InitializeComponent();
        }

        private void showTablesButton_Click(object sender, EventArgs e)
        {
            FILLDGV();
        }

        private void FILLDGV()
        {
            try
            {
                con.Open();

                List<string> tableNames = new List<string>();
                List<string> joins = new List<string>();

                if (booksTable.Checked)
                {
                    tableNames.Add("Book");
                }

                if (bookCopiesTable.Checked)
                {
                    tableNames.Add("BookCopy");
                    if (booksTable.Checked)
                    {
                        joins.Add("Book.ISBN = BookCopy.ISBN");
                    }
                }

                if (studentsTable.Checked)
                {
                    tableNames.Add("Student");
                    if (bookCopiesTable.Checked)
                    {
                        joins.Add("Student.StudentID = BookCopy.BorrowingStudentID");
                    }
                }

                if (authorsTable.Checked)
                {
                    tableNames.Add("Author");
                    if (booksTable.Checked)
                    {
                        joins.Add("Book.AuthorID = Author.AuthorID");
                    }
                }

                if (categoriesTable.Checked)
                {
                    tableNames.Add("Category");
                    if (booksTable.Checked)
                    {
                        joins.Add("Book.Category = Category.CategoryID");
                    }
                }

                if (adminsTable.Checked)
                {
                    tableNames.Add("Admin");
                    if (booksTable.Checked)
                    {
                        joins.Add("Book.PublisherID = Admin.AdminID");
                    }
                }

                if (tableNames.Count > 0)
                {
                    string query = "SELECT * FROM " + tableNames[0];

                    for (int i = 1; i < tableNames.Count; i++)
                    {
                        if (i <= joins.Count)
                        {
                            query += " JOIN " + tableNames[i] + " ON " + joins[i - 1];
                        }
                        else
                        {
                            throw new Exception("No Connection between these tables");
                        }
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    ShowTable.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Please select a table.");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("An error occurred while executing the command: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    }
}
