﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management
{
    public partial class LibraryMangement : Form
    {
        public LibraryMangement()
        {
            InitializeComponent();
        }

        private void manageBooks_Click(object sender, EventArgs e)
        {
            LibraryBookMangement libraryBookMangement = new LibraryBookMangement();
            libraryBookMangement.Show();
        }

        private void manageUsers_Click(object sender, EventArgs e)
        {
            LibraryUserManagement libraryUserMangement = new LibraryUserManagement();
            libraryUserMangement.Show();
        }

        private void showTables_Click(object sender, EventArgs e)
        {
            LibraryTables libraryTables = new LibraryTables();
            libraryTables.Show();
        }
    }
}
