﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management
{
    public partial class LibraryBookMangement : Form
    {
        SqlConnection con = new SqlConnection("Data Source=Matrix;Initial Catalog=LibraryManagementSystem;Integrated Security=True");

        public LibraryBookMangement()
        {
            InitializeComponent();
            PopulateCategoryDropdown();
            PopulatePublisherDropdown();
            PopulateAuthorDropdown();
            ClearFields();
        }

        private void insert_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "Book";

            SqlCommand cmd = new SqlCommand($"INSERT INTO [{tableName}] (ISBN, Title, PublicationYear, Category, PublisherID, AuthorID, Description, BookCopiesCount) VALUES (@ISBN, @Title, @PublicationYear, @Category, @PublisherID, @AuthorID, @Description, @BookCopiesCount)", con);

            cmd.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
            cmd.Parameters.AddWithValue("@Title", titleInput.Text);
            cmd.Parameters.AddWithValue("@PublicationYear", publicationYearInput.Text);
            cmd.Parameters.AddWithValue("@Category", categoryInput.SelectedValue);
            cmd.Parameters.AddWithValue("@PublisherID", publisherIDInput.SelectedValue);
            cmd.Parameters.AddWithValue("@AuthorID", authorIDInput.SelectedValue);
            cmd.Parameters.AddWithValue("@Description", descriptionInput.Text);
            cmd.Parameters.AddWithValue("@BookCopiesCount", bookCopiesCountInput.Value);

            cmd.ExecuteNonQuery();

            // Insert into BookCopies table
            int bookCopiesCount = Convert.ToInt32(bookCopiesCountInput.Value);
            for (int i = 0; i < bookCopiesCount; i++)
            {
                SqlCommand cmdBookCopy = new SqlCommand($"INSERT INTO [BookCopy] (ISBN) VALUES (@ISBN)", con);
                cmdBookCopy.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
                cmdBookCopy.ExecuteNonQuery();
            }

            con.Close();

            ClearFields();
        }

        private void update_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "Book";

            SqlCommand cmd = new SqlCommand($"UPDATE [{tableName}] SET Title = @Title, PublicationYear = @PublicationYear, Category = @Category, PublisherID = @PublisherID, AuthorID = @AuthorID, Description = @Description, BookCopiesCount = @BookCopiesCount WHERE ISBN = @ISBN", con);

            cmd.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
            cmd.Parameters.AddWithValue("@Title", titleInput.Text);
            cmd.Parameters.AddWithValue("@PublicationYear", publicationYearInput.Text);
            cmd.Parameters.AddWithValue("@Category", categoryInput.SelectedValue);
            cmd.Parameters.AddWithValue("@PublisherID", publisherIDInput.SelectedValue); // Use SelectedValue instead of Text
            cmd.Parameters.AddWithValue("@AuthorID", authorIDInput.SelectedValue); // Use SelectedValue instead of Text
            cmd.Parameters.AddWithValue("@Description", descriptionInput.Text);
            cmd.Parameters.AddWithValue("@BookCopiesCount", bookCopiesCountInput.Value);

            cmd.ExecuteNonQuery();

            // Update BookCopies table
            SqlCommand cmdDeleteBookCopies = new SqlCommand($"DELETE FROM [BookCopy] WHERE ISBN = @ISBN", con);
            cmdDeleteBookCopies.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
            cmdDeleteBookCopies.ExecuteNonQuery();

            int bookCopiesCount = Convert.ToInt32(bookCopiesCountInput.Value);
            for (int i = 0; i < bookCopiesCount; i++)
            {
                SqlCommand cmdBookCopy = new SqlCommand($"INSERT INTO [BookCopy] (ISBN) VALUES (@ISBN)", con);
                cmdBookCopy.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
                cmdBookCopy.ExecuteNonQuery();
            }

            con.Close();

            ClearFields();
        }
        private void delete_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "Book";

            // Delete from BookCopies table
            SqlCommand cmdDeleteBookCopies = new SqlCommand($"DELETE FROM [BookCopy] WHERE ISBN = @ISBN", con);
            cmdDeleteBookCopies.Parameters.AddWithValue("@ISBN", ISBNInput.Text);
            cmdDeleteBookCopies.ExecuteNonQuery();

            SqlCommand cmd = new SqlCommand($"DELETE FROM [{tableName}] WHERE ISBN = @ISBN", con);

            cmd.Parameters.AddWithValue("@ISBN", ISBNInput.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            ClearFields();
        }

        private void ISBNInput_TextChanged(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "Book";

            SqlCommand cmd = new SqlCommand($"SELECT * FROM [{tableName}] WHERE ISBN = @ISBN", con);
            cmd.Parameters.AddWithValue("@ISBN", ISBNInput.Text);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                titleInput.Text = reader["Title"].ToString();
                publicationYearInput.Text = reader["PublicationYear"].ToString();
                categoryInput.SelectedValue = reader["Category"];
                publisherIDInput.SelectedValue = reader["PublisherID"];
                authorIDInput.SelectedValue = reader["AuthorID"];
                descriptionInput.Text = reader["Description"].ToString();
                bookCopiesCountInput.Value = Convert.ToInt32(reader["BookCopiesCount"]);
            }
            else
            {
                titleInput.Text = "";
                publicationYearInput.Text = "";
                categoryInput.SelectedIndex = -1;
                publisherIDInput.SelectedIndex = -1;
                authorIDInput.SelectedIndex = -1;
                descriptionInput.Text = "";
                bookCopiesCountInput.Value = 1;
            }

            reader.Close();
            con.Close();
        }

        private void PopulateCategoryDropdown()
        {
            
            con.Open();
            string query = "SELECT categoryID, categoryName FROM Category";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            categoryInput.DataSource = dt;
            categoryInput.DisplayMember = "categoryName";
            categoryInput.ValueMember = "categoryID";
            con.Close();
        }

        private void PopulatePublisherDropdown()
        {
            
            con.Open();
            string query = "SELECT AdminID, firstName + ' ' + lastName AS fullName FROM Admin";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            publisherIDInput.DataSource = dt;
            publisherIDInput.DisplayMember = "fullName";
            publisherIDInput.ValueMember = "AdminID";
            con.Close();
        }

        private void PopulateAuthorDropdown()
        {
            
            con.Open();
            string query = "SELECT AuthorID, FirstName + ' ' + LastName AS FullName FROM Author";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            da.Fill(dt);

            authorIDInput.DataSource = dt;
            authorIDInput.DisplayMember = "FullName";
            authorIDInput.ValueMember = "AuthorID";
            con.Close();
        }

        private void ClearFields()
        {
            ISBNInput.Text = "";
            titleInput.Text = "";
            publicationYearInput.Text = "";
            categoryInput.SelectedIndex = -1;
            publisherIDInput.SelectedIndex = -1;
            authorIDInput.SelectedIndex = -1;
            descriptionInput.Text = "";
            bookCopiesCountInput.Value = 1;
        }
    }
}
