﻿namespace Library_Management
{
    partial class LibraryBookMangement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ISBN = new Label();
            ISBNInput = new TextBox();
            publicationYear = new Label();
            title = new Label();
            description = new Label();
            publisherID = new Label();
            authorID = new Label();
            category = new Label();
            titleInput = new TextBox();
            publicationYearInput = new TextBox();
            descriptionInput = new TextBox();
            insert = new Button();
            update = new Button();
            delete = new Button();
            bookCopiesCount = new Label();
            bookCopiesCountInput = new NumericUpDown();
            categoryInput = new ComboBox();
            publisherIDInput = new ComboBox();
            authorIDInput = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)bookCopiesCountInput).BeginInit();
            SuspendLayout();
            // 
            // ISBN
            // 
            ISBN.AutoSize = true;
            ISBN.BackColor = SystemColors.Control;
            ISBN.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            ISBN.Location = new Point(67, 9);
            ISBN.Name = "ISBN";
            ISBN.Size = new Size(59, 25);
            ISBN.TabIndex = 1;
            ISBN.Text = "ISBN";
            // 
            // ISBNInput
            // 
            ISBNInput.Location = new Point(183, 11);
            ISBNInput.Name = "ISBNInput";
            ISBNInput.Size = new Size(191, 23);
            ISBNInput.TabIndex = 5;
            ISBNInput.TextChanged += ISBNInput_TextChanged;
            // 
            // publicationYear
            // 
            publicationYear.AutoSize = true;
            publicationYear.BackColor = SystemColors.Control;
            publicationYear.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            publicationYear.Location = new Point(12, 56);
            publicationYear.Name = "publicationYear";
            publicationYear.Size = new Size(165, 25);
            publicationYear.TabIndex = 6;
            publicationYear.Text = "Publication Year";
            // 
            // title
            // 
            title.AutoSize = true;
            title.BackColor = SystemColors.Control;
            title.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            title.Location = new Point(443, 9);
            title.Name = "title";
            title.Size = new Size(54, 25);
            title.TabIndex = 7;
            title.Text = "Title";
            // 
            // description
            // 
            description.AutoSize = true;
            description.BackColor = SystemColors.Control;
            description.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            description.Location = new Point(345, 198);
            description.Name = "description";
            description.Size = new Size(118, 25);
            description.TabIndex = 8;
            description.Text = "Description";
            // 
            // publisherID
            // 
            publisherID.AutoSize = true;
            publisherID.BackColor = SystemColors.Control;
            publisherID.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            publisherID.Location = new Point(43, 104);
            publisherID.Name = "publisherID";
            publisherID.Size = new Size(100, 25);
            publisherID.TabIndex = 9;
            publisherID.Text = "Publisher";
            // 
            // authorID
            // 
            authorID.AutoSize = true;
            authorID.BackColor = SystemColors.Control;
            authorID.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            authorID.Location = new Point(428, 103);
            authorID.Name = "authorID";
            authorID.Size = new Size(77, 25);
            authorID.TabIndex = 10;
            authorID.Text = "Author";
            // 
            // category
            // 
            category.AutoSize = true;
            category.BackColor = SystemColors.Control;
            category.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            category.Location = new Point(422, 56);
            category.Name = "category";
            category.Size = new Size(96, 25);
            category.TabIndex = 11;
            category.Text = "Category";
            // 
            // titleInput
            // 
            titleInput.Location = new Point(536, 9);
            titleInput.Name = "titleInput";
            titleInput.Size = new Size(191, 23);
            titleInput.TabIndex = 12;
            // 
            // publicationYearInput
            // 
            publicationYearInput.Location = new Point(183, 58);
            publicationYearInput.Name = "publicationYearInput";
            publicationYearInput.Size = new Size(191, 23);
            publicationYearInput.TabIndex = 13;
            // 
            // descriptionInput
            // 
            descriptionInput.Location = new Point(469, 153);
            descriptionInput.Multiline = true;
            descriptionInput.Name = "descriptionInput";
            descriptionInput.Size = new Size(258, 115);
            descriptionInput.TabIndex = 17;
            // 
            // insert
            // 
            insert.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            insert.Location = new Point(77, 308);
            insert.Name = "insert";
            insert.Size = new Size(100, 53);
            insert.TabIndex = 18;
            insert.Text = "Insert";
            insert.UseVisualStyleBackColor = true;
            insert.Click += insert_Click;
            // 
            // update
            // 
            update.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            update.Location = new Point(325, 308);
            update.Name = "update";
            update.Size = new Size(107, 53);
            update.TabIndex = 19;
            update.Text = "Update";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click;
            // 
            // delete
            // 
            delete.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            delete.Location = new Point(588, 308);
            delete.Name = "delete";
            delete.Size = new Size(100, 53);
            delete.TabIndex = 20;
            delete.Text = "Delete";
            delete.UseVisualStyleBackColor = true;
            delete.Click += delete_Click;
            // 
            // bookCopiesCount
            // 
            bookCopiesCount.AutoSize = true;
            bookCopiesCount.BackColor = SystemColors.Control;
            bookCopiesCount.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            bookCopiesCount.Location = new Point(12, 198);
            bookCopiesCount.Name = "bookCopiesCount";
            bookCopiesCount.Size = new Size(183, 25);
            bookCopiesCount.TabIndex = 21;
            bookCopiesCount.Text = "Book Copies Count";
            // 
            // bookCopiesCountInput
            // 
            bookCopiesCountInput.Location = new Point(201, 200);
            bookCopiesCountInput.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            bookCopiesCountInput.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            bookCopiesCountInput.Name = "bookCopiesCountInput";
            bookCopiesCountInput.Size = new Size(120, 23);
            bookCopiesCountInput.TabIndex = 22;
            bookCopiesCountInput.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // categoryInput
            // 
            categoryInput.DropDownStyle = ComboBoxStyle.DropDownList;
            categoryInput.FormattingEnabled = true;
            categoryInput.Location = new Point(536, 61);
            categoryInput.Name = "categoryInput";
            categoryInput.Size = new Size(191, 23);
            categoryInput.TabIndex = 23;
            // 
            // publisherIDInput
            // 
            publisherIDInput.DropDownStyle = ComboBoxStyle.DropDownList;
            publisherIDInput.FormattingEnabled = true;
            publisherIDInput.Location = new Point(183, 104);
            publisherIDInput.Name = "publisherIDInput";
            publisherIDInput.Size = new Size(191, 23);
            publisherIDInput.TabIndex = 24;
            // 
            // authorIDInput
            // 
            authorIDInput.DropDownStyle = ComboBoxStyle.DropDownList;
            authorIDInput.FormattingEnabled = true;
            authorIDInput.Location = new Point(536, 104);
            authorIDInput.Name = "authorIDInput";
            authorIDInput.Size = new Size(191, 23);
            authorIDInput.TabIndex = 25;
            // 
            // LibraryBookMangement
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(750, 384);
            Controls.Add(authorIDInput);
            Controls.Add(publisherIDInput);
            Controls.Add(categoryInput);
            Controls.Add(bookCopiesCountInput);
            Controls.Add(bookCopiesCount);
            Controls.Add(delete);
            Controls.Add(update);
            Controls.Add(insert);
            Controls.Add(descriptionInput);
            Controls.Add(publicationYearInput);
            Controls.Add(titleInput);
            Controls.Add(category);
            Controls.Add(authorID);
            Controls.Add(publisherID);
            Controls.Add(description);
            Controls.Add(title);
            Controls.Add(publicationYear);
            Controls.Add(ISBNInput);
            Controls.Add(ISBN);
            Name = "LibraryBookMangement";
            Text = "Library Book Management";
            ((System.ComponentModel.ISupportInitialize)bookCopiesCountInput).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label ISBN;
        private TextBox ISBNInput;
        private Label publicationYear;
        private Label title;
        private Label description;
        private Label publisherID;
        private Label authorID;
        private Label category;
        private TextBox titleInput;
        private TextBox publicationYearInput;
        private TextBox descriptionInput;
        private Button insert;
        private Button update;
        private Button delete;
        private Label bookCopiesCount;
        private NumericUpDown bookCopiesCountInput;
        private ComboBox categoryInput;
        private ComboBox publisherIDInput;
        private ComboBox authorIDInput;
    }
}