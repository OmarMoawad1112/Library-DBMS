﻿namespace Library_Management
{
    partial class LibraryTables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            selectionLabel = new Label();
            studentsTable = new CheckBox();
            adminsTable = new CheckBox();
            authorsTable = new CheckBox();
            booksTable = new CheckBox();
            bookCopiesTable = new CheckBox();
            categoriesTable = new CheckBox();
            showTablesButton = new Button();
            ShowTable = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)ShowTable).BeginInit();
            SuspendLayout();
            // 
            // selectionLabel
            // 
            selectionLabel.AutoSize = true;
            selectionLabel.BackColor = SystemColors.Control;
            selectionLabel.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            selectionLabel.Location = new Point(12, 9);
            selectionLabel.Name = "selectionLabel";
            selectionLabel.Size = new Size(494, 37);
            selectionLabel.TabIndex = 23;
            selectionLabel.Text = "Select the Tables you want to show: ";
            // 
            // studentsTable
            // 
            studentsTable.AutoSize = true;
            studentsTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            studentsTable.Location = new Point(12, 71);
            studentsTable.Name = "studentsTable";
            studentsTable.Size = new Size(117, 34);
            studentsTable.TabIndex = 24;
            studentsTable.Text = "Students";
            studentsTable.UseVisualStyleBackColor = true;
            // 
            // adminsTable
            // 
            adminsTable.AutoSize = true;
            adminsTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            adminsTable.Location = new Point(149, 71);
            adminsTable.Name = "adminsTable";
            adminsTable.Size = new Size(107, 34);
            adminsTable.TabIndex = 25;
            adminsTable.Text = "Admins";
            adminsTable.UseVisualStyleBackColor = true;
            // 
            // authorsTable
            // 
            authorsTable.AutoSize = true;
            authorsTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            authorsTable.Location = new Point(280, 71);
            authorsTable.Name = "authorsTable";
            authorsTable.Size = new Size(110, 34);
            authorsTable.TabIndex = 26;
            authorsTable.Text = "Authors";
            authorsTable.UseVisualStyleBackColor = true;
            // 
            // booksTable
            // 
            booksTable.AutoSize = true;
            booksTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            booksTable.Location = new Point(415, 71);
            booksTable.Name = "booksTable";
            booksTable.Size = new Size(91, 34);
            booksTable.TabIndex = 27;
            booksTable.Text = "Books";
            booksTable.UseVisualStyleBackColor = true;
            // 
            // bookCopiesTable
            // 
            bookCopiesTable.AutoSize = true;
            bookCopiesTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            bookCopiesTable.Location = new Point(526, 71);
            bookCopiesTable.Name = "bookCopiesTable";
            bookCopiesTable.Size = new Size(152, 34);
            bookCopiesTable.TabIndex = 28;
            bookCopiesTable.Text = "Book Copies";
            bookCopiesTable.UseVisualStyleBackColor = true;
            // 
            // categoriesTable
            // 
            categoriesTable.AutoSize = true;
            categoriesTable.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic);
            categoriesTable.Location = new Point(694, 71);
            categoriesTable.Name = "categoriesTable";
            categoriesTable.Size = new Size(135, 34);
            categoriesTable.TabIndex = 29;
            categoriesTable.Text = "Categories";
            categoriesTable.UseVisualStyleBackColor = true;
            // 
            // showTablesButton
            // 
            showTablesButton.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            showTablesButton.Location = new Point(654, 131);
            showTablesButton.Name = "showTablesButton";
            showTablesButton.Size = new Size(175, 53);
            showTablesButton.TabIndex = 30;
            showTablesButton.Text = "Show Tables";
            showTablesButton.UseVisualStyleBackColor = true;
            showTablesButton.Click += showTablesButton_Click;
            // 
            // ShowTable
            // 
            ShowTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            ShowTable.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            ShowTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ShowTable.Location = new Point(12, 190);
            ShowTable.Name = "ShowTable";
            ShowTable.Size = new Size(817, 393);
            ShowTable.TabIndex = 31;
            // 
            // LibraryTables
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(841, 595);
            Controls.Add(ShowTable);
            Controls.Add(showTablesButton);
            Controls.Add(categoriesTable);
            Controls.Add(bookCopiesTable);
            Controls.Add(booksTable);
            Controls.Add(authorsTable);
            Controls.Add(adminsTable);
            Controls.Add(studentsTable);
            Controls.Add(selectionLabel);
            Name = "LibraryTables";
            Text = "Library Tables";
            ((System.ComponentModel.ISupportInitialize)ShowTable).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label selectionLabel;
        private CheckBox studentsTable;
        private CheckBox adminsTable;
        private CheckBox authorsTable;
        private CheckBox booksTable;
        private CheckBox bookCopiesTable;
        private CheckBox categoriesTable;
        private Button showTablesButton;
        private DataGridView ShowTable;
    }
}