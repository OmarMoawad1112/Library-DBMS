using System.Data.SqlClient;

namespace Library_Management
{
    public partial class LibraryUserManagement : Form
    {
        SqlConnection con = new SqlConnection("Data Source=Matrix;Initial Catalog=LibraryManagementSystem;Integrated Security=True");

        public LibraryUserManagement()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void insert_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "";

            if (admin.Checked)
            {
                tableName = "Admin";
            }
            else if (student.Checked)
            {
                tableName = "Student";
            }
            else if (author.Checked)
            {
                tableName = "Author";
            }

            SqlCommand cmd = new SqlCommand($"INSERT INTO [{tableName}] (Email, FirstName, LastName, Address) VALUES ('" + emailInput.Text.ToString() + "', '" + firstNameInput.Text.ToString() + "', '" + lastNameInput.Text.ToString() + "', '" + addressInput.Text.ToString() + "');", con);

            cmd.ExecuteNonQuery();
            con.Close();

            ClearFields();
        }

        private void update_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "";
            string idField = "";

            if (admin.Checked)
            {
                tableName = "Admin";
                idField = "AdminId";
            }
            else if (student.Checked)
            {
                tableName = "Student";
                idField = "StudentId";
            }
            else if (author.Checked)
            {
                tableName = "Author";
                idField = "AuthorId";
            }

            SqlCommand cmd = new SqlCommand($"UPDATE [{tableName}] SET FirstName = @FirstName, LastName = @LastName, Email = @Email, Address = @Address WHERE {idField} = @Id", con);

            cmd.Parameters.AddWithValue("@FirstName", firstNameInput.Text);
            cmd.Parameters.AddWithValue("@LastName", lastNameInput.Text);
            cmd.Parameters.AddWithValue("@Email", emailInput.Text);
            cmd.Parameters.AddWithValue("@Address", addressInput.Text);
            cmd.Parameters.AddWithValue("@Id", IDInput.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            ClearFields();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            
            con.Open();

            string tableName = "";
            string idField = "";

            if (admin.Checked)
            {
                tableName = "Admin";
                idField = "AdminId";
            }
            else if (student.Checked)
            {
                tableName = "Student";
                idField = "StudentId";
            }
            else if (author.Checked)
            {
                tableName = "Author";
                idField = "AuthorId";
            }

            SqlCommand cmd = new SqlCommand($"DELETE FROM [{tableName}] WHERE {idField} = @Id", con);

            cmd.Parameters.AddWithValue("@Id", IDInput.Text);

            cmd.ExecuteNonQuery();
            con.Close();

            ClearFields();
        }

        private void IDInput_TextChanged(object sender, EventArgs e)
        {     
            con.Open();

            string tableName = "";
            string idField = "";

            if (admin.Checked)
            {
                tableName = "Admin";
                idField = "AdminId";
            }
            else if (student.Checked)
            {
                tableName = "Student";
                idField = "StudentId";
            }
            else if (author.Checked)
            {
                tableName = "Author";
                idField = "AuthorId";
            }

            SqlCommand cmd = new SqlCommand($"SELECT * FROM [{tableName}] WHERE {idField} = @Id", con);
            cmd.Parameters.AddWithValue("@Id", IDInput.Text);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                firstNameInput.Text = reader["FirstName"].ToString();
                lastNameInput.Text = reader["LastName"].ToString();
                emailInput.Text = reader["Email"].ToString();
                addressInput.Text = reader["Address"].ToString();
            }
            else
            {
                firstNameInput.Text = "";
                lastNameInput.Text = "";
                emailInput.Text = "";
                addressInput.Text = "";
            }

            reader.Close();
            con.Close();
        }

        private void ClearFields()
        {
            IDInput.Text = "";
            firstNameInput.Text = "";
            lastNameInput.Text = "";
            emailInput.Text = "";
            addressInput.Text = "";
        }

    }
}
