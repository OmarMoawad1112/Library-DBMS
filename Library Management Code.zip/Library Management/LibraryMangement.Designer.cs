﻿namespace Library_Management
{
    partial class LibraryMangement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            manageBooks = new Button();
            manageUsers = new Button();
            showTables = new Button();
            publicationYear = new Label();
            SuspendLayout();
            // 
            // manageBooks
            // 
            manageBooks.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            manageBooks.Location = new Point(285, 142);
            manageBooks.Name = "manageBooks";
            manageBooks.Size = new Size(206, 53);
            manageBooks.TabIndex = 19;
            manageBooks.Text = "Manage Books";
            manageBooks.UseVisualStyleBackColor = true;
            manageBooks.Click += manageBooks_Click;
            // 
            // manageUsers
            // 
            manageUsers.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            manageUsers.Location = new Point(89, 83);
            manageUsers.Name = "manageUsers";
            manageUsers.Size = new Size(190, 53);
            manageUsers.TabIndex = 20;
            manageUsers.Text = "Manage Users";
            manageUsers.UseVisualStyleBackColor = true;
            manageUsers.Click += manageUsers_Click;
            // 
            // showTables
            // 
            showTables.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            showTables.Location = new Point(497, 201);
            showTables.Name = "showTables";
            showTables.Size = new Size(178, 53);
            showTables.TabIndex = 21;
            showTables.Text = "Show Tables";
            showTables.UseVisualStyleBackColor = true;
            showTables.Click += showTables_Click;
            // 
            // publicationYear
            // 
            publicationYear.AutoSize = true;
            publicationYear.BackColor = SystemColors.Control;
            publicationYear.Font = new Font("Segoe UI Black", 20.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            publicationYear.Location = new Point(12, 9);
            publicationYear.Name = "publicationYear";
            publicationYear.Size = new Size(758, 37);
            publicationYear.TabIndex = 22;
            publicationYear.Text = "Welcome to the University Library Management System";
            // 
            // LibraryMangement
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(782, 307);
            Controls.Add(publicationYear);
            Controls.Add(showTables);
            Controls.Add(manageUsers);
            Controls.Add(manageBooks);
            Name = "LibraryMangement";
            Text = "LibraryMangement";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button manageBooks;
        private Button manageUsers;
        private Button showTables;
        private Label publicationYear;
    }
}