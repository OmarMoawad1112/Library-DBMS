﻿namespace Library_Management
{
    partial class LibraryUserManagement
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            firstName = new Label();
            firstNameInput = new TextBox();
            lastName = new Label();
            lastNameInput = new TextBox();
            email = new Label();
            emailInput = new TextBox();
            address = new Label();
            addressInput = new TextBox();
            student = new RadioButton();
            admin = new RadioButton();
            author = new RadioButton();
            insert = new Button();
            update = new Button();
            ID = new Label();
            IDInput = new TextBox();
            delete = new Button();
            userSelection = new Label();
            SuspendLayout();
            // 
            // firstName
            // 
            firstName.AutoSize = true;
            firstName.BackColor = SystemColors.Control;
            firstName.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            firstName.Location = new Point(15, 129);
            firstName.Name = "firstName";
            firstName.Size = new Size(114, 25);
            firstName.TabIndex = 0;
            firstName.Text = "First Name";
            // 
            // firstNameInput
            // 
            firstNameInput.Location = new Point(135, 132);
            firstNameInput.Name = "firstNameInput";
            firstNameInput.Size = new Size(191, 23);
            firstNameInput.TabIndex = 4;
            // 
            // lastName
            // 
            lastName.AutoSize = true;
            lastName.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            lastName.Location = new Point(359, 132);
            lastName.Name = "lastName";
            lastName.Size = new Size(112, 25);
            lastName.TabIndex = 2;
            lastName.Text = "Last Name";
            // 
            // lastNameInput
            // 
            lastNameInput.Location = new Point(477, 134);
            lastNameInput.Name = "lastNameInput";
            lastNameInput.Size = new Size(191, 23);
            lastNameInput.TabIndex = 6;
            // 
            // email
            // 
            email.AutoSize = true;
            email.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            email.Location = new Point(33, 177);
            email.Name = "email";
            email.Size = new Size(72, 25);
            email.TabIndex = 5;
            email.Text = "E-mail";
            // 
            // emailInput
            // 
            emailInput.Location = new Point(135, 177);
            emailInput.Name = "emailInput";
            emailInput.Size = new Size(191, 23);
            emailInput.TabIndex = 8;
            // 
            // address
            // 
            address.AutoSize = true;
            address.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            address.Location = new Point(369, 177);
            address.Name = "address";
            address.Size = new Size(86, 25);
            address.TabIndex = 7;
            address.Text = "Address";
            // 
            // addressInput
            // 
            addressInput.Location = new Point(477, 179);
            addressInput.Name = "addressInput";
            addressInput.Size = new Size(191, 23);
            addressInput.TabIndex = 3;
            // 
            // student
            // 
            student.AutoSize = true;
            student.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            student.Location = new Point(348, 23);
            student.Name = "student";
            student.Size = new Size(107, 34);
            student.TabIndex = 11;
            student.TabStop = true;
            student.Text = "Student";
            student.UseVisualStyleBackColor = true;
            // 
            // admin
            // 
            admin.AutoSize = true;
            admin.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            admin.Location = new Point(466, 23);
            admin.Name = "admin";
            admin.Size = new Size(97, 34);
            admin.TabIndex = 12;
            admin.TabStop = true;
            admin.Text = "Admin";
            admin.UseVisualStyleBackColor = true;
            // 
            // author
            // 
            author.AutoSize = true;
            author.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            author.Location = new Point(575, 23);
            author.Name = "author";
            author.Size = new Size(100, 34);
            author.TabIndex = 13;
            author.TabStop = true;
            author.Text = "Author";
            author.UseVisualStyleBackColor = true;
            // 
            // insert
            // 
            insert.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            insert.Location = new Point(84, 228);
            insert.Name = "insert";
            insert.Size = new Size(100, 53);
            insert.TabIndex = 1;
            insert.Text = "Insert";
            insert.UseVisualStyleBackColor = true;
            insert.Click += insert_Click;
            // 
            // update
            // 
            update.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            update.Location = new Point(298, 228);
            update.Name = "update";
            update.Size = new Size(107, 53);
            update.TabIndex = 9;
            update.Text = "Update";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click;
            // 
            // ID
            // 
            ID.AutoSize = true;
            ID.BackColor = SystemColors.Control;
            ID.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            ID.Location = new Point(89, 83);
            ID.Name = "ID";
            ID.Size = new Size(312, 25);
            ID.TabIndex = 15;
            ID.Text = "ID if you are already registered: ";
            // 
            // IDInput
            // 
            IDInput.Location = new Point(401, 85);
            IDInput.Name = "IDInput";
            IDInput.Size = new Size(191, 23);
            IDInput.TabIndex = 14;
            IDInput.TextChanged += IDInput_TextChanged;
            // 
            // delete
            // 
            delete.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            delete.Location = new Point(487, 228);
            delete.Name = "delete";
            delete.Size = new Size(100, 53);
            delete.TabIndex = 10;
            delete.Text = "Delete";
            delete.UseVisualStyleBackColor = true;
            delete.Click += delete_Click;
            // 
            // userSelection
            // 
            userSelection.AutoSize = true;
            userSelection.BackColor = SystemColors.Control;
            userSelection.Font = new Font("Segoe UI Black", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            userSelection.Location = new Point(12, 29);
            userSelection.Name = "userSelection";
            userSelection.Size = new Size(322, 25);
            userSelection.TabIndex = 16;
            userSelection.Text = "Please select your UserType first: ";
            // 
            // LibraryUserManagement
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(687, 308);
            Controls.Add(userSelection);
            Controls.Add(ID);
            Controls.Add(IDInput);
            Controls.Add(firstName);
            Controls.Add(firstNameInput);
            Controls.Add(lastName);
            Controls.Add(lastNameInput);
            Controls.Add(email);
            Controls.Add(emailInput);
            Controls.Add(address);
            Controls.Add(addressInput);
            Controls.Add(student);
            Controls.Add(admin);
            Controls.Add(author);
            Controls.Add(insert);
            Controls.Add(update);
            Controls.Add(delete);
            Name = "LibraryUserManagement";
            Text = "Library User Mangement";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label firstName;
        private TextBox firstNameInput;
        private Label lastName;
        private TextBox lastNameInput;
        private Label email;
        private TextBox emailInput;
        private Label address;
        private TextBox addressInput;
        private RadioButton student;
        private RadioButton admin;
        private RadioButton author;
        private Button insert;
        private Button update;
        private Label ID;
        private TextBox IDInput;
        private Button delete;
        private Label userSelection;
    }
}
